@extends('layouts.app')

@section('title', $usuario->name)

@section('content')

<div class="container">

	<div class="bg-white p-5 redounded shadow">
		

	<h1>{{$usuario->name}}</h1>
	<p class="lead text-secondary"></p>

	<p class="text-secondary"> Correo Electrónico: {{$usuario->email}}  </p>

	{{-- <p class="text-secondary"> Dirección : {{$cliente->direccion}}  </p> --}}

	<p class="text-secondary"> Rol: {{ $rol->rols }}  </p>

	{{-- <p class="text-secondary"> Teléfono fijo: {{ $cliente->telefono }}  </p>	 --}}

	{{-- <p class="text-secondary"> Teléfono Celular: {{$cliente->cel}}  </p> --}}

	
	
	<p class="text-black-50">Creado {{$usuario->created_at->diffForHumans()}}</p>
	
	@if(is_null($usuario->updated_at))

		<p>Sin actualizaciones</p> 
	
	@else

		<p class="text-black-50">Actualizado {{$usuario->updated_at->diffForHumans()}}</p>
	

	@endif

	<dic class="d-flex justify-content-between align-items-center">	



		<a class="btn btn-primary" href="{{route('usuarios.index')}}">Regresar</a>
		
	@auth
	<div class="btn-group btn-group-sm">
		<a class="btn btn-primary" 
		href="{{route('usuarios.edit', $usuario)}}"
		>Editar</a>

		<a class="btn btn-danger"
		href="#" onclick="document.getElementById('delete-usuario').submit()"
		>Eliminar</a>
		
	</div>	
		<form class="d-none" id="delete-usuario" method="POST" action="{{route('usuarios.destroy', $usuario)}}">

			@csrf @method('DELETE')
			
		</form>	

	
	@endauth
	</div>
</div>	
</div>
</div>

	
@endsection
