@csrf 	

			<div class="col-6">
				<label  for="nombre" >Nombres :</label> 			
				<input class="form-control bg-light shadow-sm  @error('name') is-invalid @else border-0 @enderror  " type="text" name="name" id="nombre" onkeyup="mayusculas(this);"
				value="{{old('name', $usuario->name) }}" maxlength="60">
				@error('name')<span class="invalid-feedback" role="alert">{{$message}}</span>@enderror
				
				<label  for="email" >Correo Electrónico :</label>  			
				<input class="form-control bg-light shadow-sm @error('email') is-invalid @else border-0 @enderror "style="" type="email" name="email" id="email" onkeyup="minusculas(this);"
				value="{{old('email', $usuario->email) }}" maxlength="100">@error('email')<span class="invalid-feedback" role="alert">{{$message}}</span>@enderror
				
				<label  for="id_rol" >Rol :</label>  
	                <select name ="id_rol" id="id_rol"  class="form-control" @error('id_rol') is-invalid @else border-0 @enderror >
	                	<option value="{{$cbid}}">{{$cbd}}</option>
	                    @foreach($rols as $rol)
	                        <option value="{{$rol->id}}">{{$rol->rols}}</option>
	                    @endforeach
	                </select>
	                <p></p>  
			</div>
			<p></p>
			<br>
		<button class="btn btn-primary ml-4 mx4 my-4">{{$btntext}}</button>
