@extends('layouts.app')

@section('title', 'Proveedores')


@section('content')

<div class="container">	
	<div class="d-flex justify-content-between aling-items-center mb-3">
		
	<h1 class="display-4 mb-0">Proveedores</h1>
	
	@auth

		<a class="btn btn-primary  my-auto" 
			href = "{{route('proveedores.create')}}"
			>Agregar Proveedor
		</a>

	@endauth
	</div>

	
	<p class="lead text-secondary"></p>

<ul class="list-group text-secondary">
		
		@forelse ($proveedores as $proveedor) 
			<li class="list-group-item border-0 mb-3 shadow-sm">
				<a 
				class="d-flex text-secondary justify-content-between aling-item-center" 
				href="{{route('proveedores.show',$proveedor)}}">
				<spam class="font-weight-bold">
					{{$proveedor->nombre}}
				</spam>

				<spam class="text-black-50">
					{{$proveedor->created_at->format('d/m/y')}}
				</spam>	

				</a></li>
		@empty
	
			<li class="list-group-item border-0 mb-3 shadow-sm">
				No hay registros
			</li>

	@endforelse
	
		{{$proveedores->links()}}

</ul>

</div>
@endsection