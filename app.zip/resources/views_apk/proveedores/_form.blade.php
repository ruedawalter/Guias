@csrf 	

		
		<div class="row">
			
			<div class="col-6">
				<label  for="nombre" >Nombres :</label> 			
				<input class="form-control bg-light shadow-sm  @error('nombre') is-invalid @else border-0 @enderror "style="text-transform:uppercase;" type="text" name="nombre" 
				value="{{old('nombre', $proveedor->nombre) }}" maxlength="60">
				@error('nombre')<span class="invalid-feedback" role="alert">{{$message}}</span>@enderror
				
				<label  for="email" >Correo Electrónico :</label>  			
				<input class="form-control bg-light shadow-sm @error('email') is-invalid @else border-0 @enderror "style="text-transform:uppercase;" type="email" name="email"
				value="{{old('email', $proveedor->email) }}" maxlength="100">@error('email')<span class="invalid-feedback" role="alert">{{$message}}</span>@enderror

				<label  for="direccion" >Direción:</label>  			
				<input class="form-control bg-light shadow-sm @error('direccion') is-invalid @else border-0 @enderror "style="text-transform:uppercase;" type="text" name="direccion" 
				value="{{old('direccion', $proveedor->direccion) }}" maxlength="100">
				@error('direccion')<span class="invalid-feedback" role="alert">{{$message}}</span>@enderror			
			</div>
			<p></p>
			<div class="col-6">
				<label  for="telefono" >Teléfono Fijo:</label> 			
				<input class="form-control bg-light shadow-sm @error('telefono') is-invalid @else border-0 @enderror "style="text-transform:uppercase;" type="text" name="telefono" 
				value="{{old('telefono', $proveedor->telefono) }}" maxlength="10">
				@error('cel')<span class="invalid-feedback" role="alert">{{$message}}</span>@enderror
				
				<label  for="cel" >Teléfono Celular:</label>  			
				<input class="form-control bg-light shadow-sm @error('cel') is-invalid @else border-0 @enderror "style="text-transform:uppercase;" type="text" name="cel" 
				value="{{old('cel', $proveedor->cel) }}" maxlength="9">
				@error('cel')<span class="invalid-feedback" role="alert">{{$message}}</span>@enderror

				<label  for="distrito_id" >Distrito :</label>  
	                <select name ="distrito_id" id="distrito_id"  class="form-control" @error('distrito_id') is-invalid @else border-0 @enderror >
	                	<option value="{{$cbid}}">{{$cbd}}</option>
	                    @foreach($distritos as $distrito)
	                        <option value="{{$distrito->id}}">{{$distrito->distrito}}</option>
	                    @endforeach
	                </select>
	                <p></p>  
			</div>
			<p></p>
			<br>
		<button class="btn btn-primary ml-4 mx4 my-4">{{$btntext}}</button>
