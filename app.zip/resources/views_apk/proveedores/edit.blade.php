xtends('layouts.app')

@section('title', 'Editar Proveedores')


@section('content')

<div class="card py-2 px2 mx-4 my-4">

	
	{{-- <div class="justify-content-center">
		<div class="col-md-8 col-lg-6 col-sm-10 mx-auto"> --}}

	<form class="bg-white py-1 px-2 shadow redounded" method="POST" action="{{ route('proveedores.update', $proveedor) }}">
		<h1>Editar Proveedores</h1>
		<hr>
		
		
		@method('PATCH')
		
		@include('proveedores._form', ['btntext' => 'Actualizar'])
		<a class="btn btn-secondary mx4 my-4" href="{{route('proveedores.index')}}">Cancelar</a>

	</form>
</div>
</div>
</div>
@endsection