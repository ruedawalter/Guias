@extends('layouts.app')

@section('title', $proveedor->nombre)

@section('content')

<div class="container">

	<div class="bg-white p-5 redounded shadow">
		

	<h1>{{$proveedor->nombre}}</h1>
	<p class="lead text-secondary"></p>

	<p class="text-secondary"> Dirección : {{$proveedor->direccion}}  </p>

	<p class="text-secondary"> Distrito: {{ $dist->distrito }}  </p>

	<p class="text-secondary"> Teléfono fijo: {{ $proveedor->telefono }}  </p>	

	<p class="text-secondary"> Teléfono Celular: {{$proveedor->cel}}  </p>

	<p class="text-secondary"> Correo Electrónico: {{$proveedor->email}}  </p>
	
	<p class="text-black-50">Creado {{$proveedor->created_at->diffForHumans()}}</p>
	
	@if(is_null($proveedor->updated_at))

		<p>Sin actualizaciones</p> 
	
	@else

		<p class="text-black-50">Actualizado {{$proveedor->updated_at->diffForHumans()}}</p>
	

	@endif

	<dic class="d-flex justify-content-between align-items-center">	



		<a class="btn btn-primary" href="{{route('proveedores.index')}}">Regresar</a>
		
	@auth
	<div class="btn-group btn-group-sm">
		<a class="btn btn-primary" 
		href="{{route('proveedores.edit', $proveedor)}}"
		>Editar</a>

		<a class="btn btn-danger"
		href="#" onclick="document.getElementById('delete-proveedor').submit()"
		>Eliminar</a>
		
	</div>	
		<form class="d-none" id="delete-proveedor" method="POST" action="{{route('proveedores.destroy', $proveedor)}}">

			@csrf @method('DELETE')
			
		</form>	

	
	@endauth
	</div>
</div>	
</div>
</div>

	
@endsection
