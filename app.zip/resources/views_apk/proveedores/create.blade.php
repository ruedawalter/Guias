@extends('layouts.app')

@section('title', 'Agregar Proveedor')


@section('content')

<div class="card py-2 px2 mx-4 my-4">

	
	{{-- <div class="justify-content-center">
		<div class="col-md-8 col-lg-6 col-sm-10 mx-auto"> --}}

	<form class="bg-white py-1 px-2 shadow redounded" method="POST" action="{{ route('proveedores.store') }}">
		<h3 class="card-header">Nuevo Proveedor</h3>
		<br>
							
		@include('proveedores._form', ['btntext' => 'Guardar'] )
		<a class="btn btn-secondary mx4 my-4" href="{{route('proveedores.index')}}">Cancelar</a>	
		 <br>

	</form>

</div>
{{-- </div> --}}

@endsection