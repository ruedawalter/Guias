<footer class="bg-white text-center text-black-50 ">
			{{ config('app.name') }}  | Copyrigths @ {{ date('Y') }} WR Soluciones <a class="img-fluid " href="https://wa.me/51917921461">
			<img class="img-fluid" src="{{ asset('img/whatsapp.png') }}" width="15" height="15"></a>
</footer>