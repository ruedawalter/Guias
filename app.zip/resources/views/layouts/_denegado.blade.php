<p></p>
<p></p>
<hr>
<body class="h-100 bg-alert">
    <div class="container h-100">
        <div class="row justify-content-center h-100">
            <div class="col-sm-8 align-self-center text-center">
                <div class="card shadow ">
                    <div class="card-body shadow">
                      <h1 class="m-5"><i class="fas fa-user-times"></i>  No esta autorizado a ver este contenido</h1>
                      <span><a class="btn btn-secondary" href="{{('home')}}" alt="Nuevo Usuario"><i class="fas fa-reply-all"></i> Inicio</a></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
