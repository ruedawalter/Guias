@extends('layouts.app')

@section('content')

{{-- <div align="center"><img src="img/fond.jpg" width="25%" height="25%"></div> --}}
<div align="center"><img src="img/logo.png" width="25%" height="25%"></div>
{{-- <div align="center"><img src="img/logo.png" width="25%" height="25%"></div> --}}
{{-- <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8"> --}}
            {{-- <div class="card"> --}}
                {{-- <div class="card-header">{{ __('Dashboard') }}</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    {{ __('You are logged in!') }}
                </div> --}}
            {{-- </div> --}}
        {{-- </div>
    </div>
</div> --}}

</body>
@endsection
