

<?php $__env->startSection('title', 'Editar Estados'); ?>


<?php $__env->startSection('content'); ?>

<div class="container">

	<div class="row row justify-content-center">
		<div class="col-md-8 col-lg-6 col-sm-10 mx-auto">

	

	<form class="bg-white py-3 px-4 shadow redounded" method="POST" action="<?php echo e(route('estados.update', $estado)); ?>">
		<h4>Editar Estados</h4>
		<hr>
		
		
		<?php echo method_field('PATCH'); ?>
		
		<?php echo $__env->make('estados._form', ['btntext' => 'Actualizar'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<a class="btn btn-secondary ml-4 mx4 my-4" href="<?php echo e(route('estados.index')); ?>">Cancelar</a>

	</form>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon32\www\app\resources\views/estados/edit.blade.php ENDPATH**/ ?>