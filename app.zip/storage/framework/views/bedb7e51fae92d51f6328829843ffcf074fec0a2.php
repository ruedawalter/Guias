

<?php $__env->startSection('title', 'Distrito | ' . $distrito->distrito); ?>

<?php $__env->startSection('content'); ?>

<div class="container">

	<div class="bg-white p-5 redounded shadow">
		

	<h4>Distrito <?php echo e($distrito->distrito); ?>   <?php echo e($distrito->id); ?></h4>
	<p class="lead text-secondary">Distritos de Lima Metropolitana</p>

	<p class="text-secondary"> <?php echo e($distrito->distrito); ?>  </p>
	
	<p class="text-black-50">Creado <?php echo e($distrito->created_at->diffForHumans()); ?></p>
	
	<?php if(is_null($distrito->updated_at)): ?>

		<p>Sin actualizaciones</p> 
	
	<?php else: ?>

		<p class="text-black-50">Actualizado <?php echo e($distrito->updated_at->diffForHumans()); ?></p>
	

	<?php endif; ?>

	<dic class="d-flex justify-content-between align-items-center">	



		<a class="btn btn-primary" href="<?php echo e(route('distritos.index')); ?>">Regresar</a>
		
	<?php if(auth()->guard()->check()): ?>
	<div class="btn-group btn-group-sm">
		<a class="btn btn-primary" 
		href="<?php echo e(route('distritos.edit', $distrito)); ?>"
		>Editar</a>

		<a class="btn btn-danger"
		href="#" onclick="document.getElementById('delete-distrito').submit()"
		>Eliminar</a>
		
	</div>	
		<form class="d-none" id="delete-distrito" method="POST" action="<?php echo e(route('distritos.destroy', $distrito)); ?>">

			<?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
			
		</form>	

	
	<?php endif; ?>
	</div>
</div>	
</div>
</div>

	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\app\resources\views/distritos/show.blade.php ENDPATH**/ ?>