

<?php $__env->startSection('title', $cliente->nombre); ?>

<?php $__env->startSection('content'); ?>

<div class="container">

	<div class="bg-white p-5 redounded shadow">
		

	<h1><?php echo e($cliente->nombre); ?></h1>
	<p class="lead text-secondary"></p>

	<p class="text-secondary"> Dirección : <?php echo e($cliente->direccion); ?>  </p>

	<p class="text-secondary"> Distrito: <?php echo e($dist->distrito); ?>  </p>

	<p class="text-secondary"> Teléfono fijo: <?php echo e($cliente->telefono); ?>  </p>	

	<p class="text-secondary"> Teléfono Celular: <?php echo e($cliente->cel); ?>  </p>

	<p class="text-secondary"> Correo Electrónico: <?php echo e($cliente->email); ?>  </p>
	
	<p class="text-black-50">Creado <?php echo e($cliente->created_at->diffForHumans()); ?></p>
	
	<?php if(is_null($cliente->updated_at)): ?>

		<p>Sin actualizaciones</p> 
	
	<?php else: ?>

		<p class="text-black-50">Actualizado <?php echo e($cliente->updated_at->diffForHumans()); ?></p>
	

	<?php endif; ?>

	<dic class="d-flex justify-content-between align-items-center">	



		<a class="btn btn-primary" href="<?php echo e(route('clientes.index')); ?>">Regresar</a>
		
	<?php if(auth()->guard()->check()): ?>
	<?php if(Auth::user()->id_rol == "3"): ?>
	<div class="btn-group btn-group-sm">
		<a class="btn btn-primary" 
		href="<?php echo e(route('clientes.edit', $cliente)); ?>"
		>Editar</a>

		<a class="btn btn-danger"
		href="#" onclick="document.getElementById('delete-cliente').submit()"
		>Eliminar</a>
		
		
	</div>	
		<form class="d-none" id="delete-cliente" method="POST" action="<?php echo e(route('clientes.destroy', $cliente)); ?>">

			<?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
			
		</form>	
	<?php endif; ?>	
	
	<?php endif; ?>
	</div>
</div>	
</div>
</div>

	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon32\www\app\resources\views/clientes/show.blade.php ENDPATH**/ ?>