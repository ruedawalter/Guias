

<?php $__env->startSection('title', $servicio->nombre); ?>

<?php $__env->startSection('content'); ?>

<div class="container">

	<div class="bg-white p-5 redounded shadow">
		

	<h6>Servicio: <?php echo e($servicio->nombre); ?></h6>
	<p class="lead text-secondary"></p>

	<p class="text-secondary"> <?php echo e($servicio->nombre); ?>  </p>
	
	<p class="text-black-50">Creado <?php echo e($servicio->created_at->diffForHumans()); ?></p>
	
	<?php if(is_null($servicio->updated_at)): ?>

		<p>Sin actualizaciones</p> 
	
	<?php else: ?>

		<p class="text-black-50">Actualizado <?php echo e($servicio->updated_at->diffForHumans()); ?></p>
	

	<?php endif; ?>

	<dic class="d-flex justify-content-between align-items-center">	



		<a class="btn btn-primary" href="<?php echo e(route('servicios.index')); ?>">Regresar</a>
		
	<?php if(auth()->guard()->check()): ?>
	<div class="btn-group btn-group-sm">
		<a class="btn btn-primary" 
		href="<?php echo e(route('servicios.edit', $servicio)); ?>"
		>Editar</a>

		<a class="btn btn-danger"
		href="#" onclick="document.getElementById('delete-servicio').submit()"
		>Eliminar</a>
		
	</div>	
		<form class="d-none" id="delete-servicio" method="POST" action="<?php echo e(route('servicios.destroy', $servicio)); ?>">

			<?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
			
		</form>	

	
	<?php endif; ?>
	</div>
</div>	
</div>
</div>

	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon32\www\app\resources\views/servicios/show.blade.php ENDPATH**/ ?>