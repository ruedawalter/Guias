<?php echo csrf_field(); ?> 	

		<div class="form-group">

			<label  for="distrito" >Nombre Distrito:</label>  
			
			<input class="form-control bg-light shadow-sm <?php $__errorArgs = ['distrito'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php else: ?> border-0 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> "style="text-transform:uppercase;" type="text" name="distrito" 
			value="<?php echo e(old('distrito', $distrito->distrito)); ?>">
			<?php $__errorArgs = ['distrito'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>	
		
		

		<button class="btn btn-primary"><?php echo e($btntext); ?></button><?php /**PATH C:\laragon32\www\app\resources\views/distritos/_form.blade.php ENDPATH**/ ?>