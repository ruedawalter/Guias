
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-11">
                <h2>Bancos</h2>
        </div>
        <div class="col-lg-1">
            <a class="btn btn-success" href="#" data-toggle="modal" data-target="#addModal">Nuevo</a>
        </div>
    </div>
      

     
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    <div class="container">
    <table class="table table-bordered py2 px-2" id="bancoTable" width="90%">
		<thead>
			<tr>
				<th>id</th>
				<th>Banco</th>
				<th width="200px">Accion</th>
			</tr>
		</thead>	
		<tbody>
        <?php $__currentLoopData = $bancos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id="<?php echo e($banco->id); ?>">
                <td><?php echo e($banco->id); ?></td>
                <td><?php echo e($banco->nombre); ?></td>
                <td>
		     <a data-id="<?php echo e($banco->id); ?>" class="btn btn-primary btnEdit">Editar</a>
		     <a data-id="<?php echo e($banco->id); ?>" class="btn btn-danger btnDelete">Eliminar</button>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
    </table>
	</div>

<!-- Add Banco Modal -->
<div id="addModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Banco Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"></h4>
      </div>
	  <div class="modal-body">
		<form id="addBanco" name="addBanco" action="<?php echo e(route('bancos.store')); ?>" method="post">
			<?php echo csrf_field(); ?>
			<div class="form-group">
				<label for="txtNombre">Nombres:</label>
				<input type="text" class="form-control" id="txtNombre" placeholder="Ingrese el nombre del banco" name="txtNombre" onkeyup="mayusculas(this);">
			</div>
			
			<button type="submit" class="btn btn-primary">Guardar</button>
		</form>
	  </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>	
<!-- Update Banco Modal -->
<div id="updateModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Banco Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Actualizar Banco</h4>
      </div>
	  <div class="modal-body">
		<form id="updateBanco" name="updateBanco" action="<?php echo e(route('bancos.update')); ?>" method="post">
			<input type="hidden" name="hdnBancoId" id="hdnBancoId"/>
			<?php echo csrf_field(); ?>
			<div class="form-group">
				<label for="txtNombre">Nombre:</label>
				<input type="text" class="form-control" id="txtNombre" placeholder="Ingrese el nombre del banco" name="txtNombre" onkeyup="mayusculas(this);">
			</div>
			
			<button type="submit" class="btn btn-primary">Guardar</button>
		</form>
	  </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>	

<script>
  $(document).ready(function () {
	//Add the Banco  
	$("#addBanco").validate({
		 rules: {
				txtFirstName: "required"
				// txtLastName: "required",
				// txtAddress: "required"
			},
			messages: {
			},
 
		 submitHandler: function(form) {
		  var form_action = $("#addBanco").attr("action");
		  $.ajax({
			  data: $('#addBanco').serialize(),
			  url: form_action,
			  type: "POST",
			  dataType: 'json',
			  success: function (data) {
				  var banco = '<tr id="'+data.id+'">';
				  banco += '<td>' + data.id + '</td>';
				  banco += '<td>' + data.nombre + '</td>';
				  // Banco += '<td>' + data.last_name + '</td>';
				  // Banco += '<td>' + data.address + '</td>';
				  banco += '<td><a data-id="' + data.id + '" class="btn btn-primary btnEdit">Editar</a>&nbsp;&nbsp;<a data-id="' + data.id + '" class="btn btn-danger btnDelete">Eliminar</a></td>';
				  banco += '</tr>';            
				  $('#bancoTable tbody').prepend(banco);
				  $('#addBanco')[0].reset();
				  $('#addModal').modal('hide');
			  },
			  error: function (data) {'algo salio mal'
			  }
		  });
		}
	});
  
 
    //When click edit banco
    $('body').on('click', '.btnEdit', function () {
      var banco_id = $(this).attr('data-id');
      $.get('bancos/' + banco_id +'/edit', function (data) {
          $('#updateModal').modal('show');
          $('#updateBanco #hdnBancoId').val(data.id); 
          $('#updateBanco #txtNombre').val(data.nombre);
          // $('#updateBanco #txtLastName').val(data.last_name);
          // $('#updateBanco #txtAddress').val(data.address);
      })
   });
    // Update the banco
	$("#updateBanco").validate({
		 rules: {
				txtFirstName: "required"
				// txtLastName: "required",
				// txtAddress: "required"
				
			},
			messages: {
			},
 
		 submitHandler: function(form) {
		  var form_action = $("#updateBanco").attr("action");
		  $.ajax({
			  data: $('#updateBanco').serialize(),
			  url: form_action,
			  type: "POST",
			  dataType: 'json',
			  success: function (data) {
				  var banco = '<td>' + data.id + '</td>';
				  banco += '<td>' + data.nombre + '</td>';
				  // banco += '<td>' + data.last_name + '</td>';
				  // banco += '<td>' + data.address + '</td>';
				  banco += '<td><a data-id="' + data.id + '" class="btn btn-primary btnEdit">Editar</a>&nbsp;&nbsp;<a data-id="' + data.id + '" class="btn btn-danger btnDelete">Eliminar</a></td>';
				  $('#bancoTable tbody #'+ data.id).html(banco);
				  $('#updateBanco')[0].reset();
				  $('#updateModal').modal('hide');
			  },
			  error: function (data) {
			  }
		  });
		}
	});		
		
   //delete banco
	$('body').on('click', '.btnDelete', function () {
      var banco_id = $(this).attr('data-id');
      $.get('bancos/' + banco_id +'/delete', function (data) {
          $('#bancoTable tbody #'+ banco_id).remove();
      })
   });	
	
});	  
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon32\www\app\resources\views/bancos/index.blade.php ENDPATH**/ ?>