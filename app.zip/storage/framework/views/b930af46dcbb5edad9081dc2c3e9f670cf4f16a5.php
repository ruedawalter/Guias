

<?php $__env->startSection('title', $usuario->name); ?>

<?php $__env->startSection('content'); ?>

<div class="container">

	<div class="bg-white p-5 redounded shadow">
		

	<h1><?php echo e($usuario->name); ?></h1>
	<p class="lead text-secondary"></p>

	<p class="text-secondary"> Correo Electrónico: <?php echo e($usuario->email); ?>  </p>

	

	<p class="text-secondary"> Rol: <?php echo e($rol->rols); ?>  </p>

	

	

	
	
	<p class="text-black-50">Creado <?php echo e($usuario->created_at->diffForHumans()); ?></p>
	
	<?php if(is_null($usuario->updated_at)): ?>

		<p>Sin actualizaciones</p> 
	
	<?php else: ?>

		<p class="text-black-50">Actualizado <?php echo e($usuario->updated_at->diffForHumans()); ?></p>
	

	<?php endif; ?>

	<dic class="d-flex justify-content-between align-items-center">	



		<a class="btn btn-primary" href="<?php echo e(route('usuarios.index')); ?>">Regresar</a>
		
	<?php if(auth()->guard()->check()): ?>
	<div class="btn-group btn-group-sm">
		<a class="btn btn-primary" 
		href="<?php echo e(route('usuarios.edit', $usuario)); ?>"
		>Editar</a>

		<a class="btn btn-danger"
		href="#" onclick="document.getElementById('delete-usuario').submit()"
		>Eliminar</a>
		
	</div>	
		<form class="d-none" id="delete-usuario" method="POST" action="<?php echo e(route('usuarios.destroy', $usuario)); ?>">

			<?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
			
		</form>	

	
	<?php endif; ?>
	</div>
</div>	
</div>
</div>

	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\app\resources\views/usuarios/show.blade.php ENDPATH**/ ?>