<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Reporte de Guias</title>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<style type="text/css">
  		@page  {
  			size: 29.7cm 21cm;
  			margin: 0cm;
  			font-size: 12px;
  		}
  		body {
       margin: 0cm;

  		}
  		header {
  			position: fixed;
  			top: 0cm;
  			left:0cm;
  			right: 0cm;
  			height: 1cm;
  			/*background-color: #2f069d;*/
  			color: #fe5442;
  			text-align: center;
  			line-height: 25px;
  		}
  		footer {
  			position: fixed;
  			bottom: 0cm;
  			left:0cm;
  			right: 0cm;
  			height: 1cm;
  			background-color: #2f069d;
  			color: #fe5442;
  			text-align: center;
  			line-height: 25px;
  		}
  		.page-break {
    			page-break-after: always;
		}
	</style>
</head>
<body>
	<header>
		<img alt="Gutierrez Courier" src="img/logo.png" width="50" height="50" ><p><strong>Control de Guias V-1.0</p></strong>
	</head>
<div class="container">
	<h5 style="text-align: center">Reporte de Guias</h5>
<table class="table table-striped text-center">
  <thead>
    <tr>
      <th scope="col">Fecha</th>
      <th scope="col">Guia</th>
      <th scope="col">Cliente</th>
      <th scope="col">Distrito</th>
      <th scope="col">Remitente</th>
      <th scope="col">Monto</th>
      <th scope="col">Monto Servicio</th>
      <th scope="col">Monto a cobrar</th>
      <th scope="col">Agente</th>

    </tr>
  </thead>
  <tbody>
  	<?php $__currentLoopData = $guias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guias): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($guias->fecha); ?></th>
      <td><?php echo e($guias->guia); ?></td>
      <td><?php echo e($guias->cliente); ?></td>
      <td><?php echo e($guias->distrito); ?></td>
      <td><?php echo e($guias->remitente); ?></td>
      <td><?php echo e(number_format($guias->monto, 2)); ?></td>
      <td><?php echo e(number_format($guias->smonto, 2)); ?></td>
      <td><?php echo e(number_format($guias->totald, 2)); ?></td>
      <td><?php echo e($guias->agente); ?></td>

    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </tbody>
</table>
</div>

	<div>Total  Cobrado = 2000 </div>
  <div>Total  Cobrado = 2000 </div>
  <div>Total  Cobrado = 2000 </div>

<script type="text/php">
        if ( isset($pdf) ) {
            $pdf->page_script('
                $font = $fontMetrics->get_font("Arial, Helvetica, sans-serif", "normal");
                $pdf->text(730, 570, "Pág $PAGE_NUM de $PAGE_COUNT", $font, 10);
                $pdf->text(62, 570, "https://gutierrezcourier.com" , $font, 10);
            ');
        }
    	</script>
</body>
</html><?php /**PATH C:\laragon\www\app\resources\views/admgg.blade.php ENDPATH**/ ?>