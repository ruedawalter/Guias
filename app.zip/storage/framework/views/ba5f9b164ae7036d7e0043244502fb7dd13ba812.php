<script src="js/3.1.1.jquery.min.js"></script>
<script src="js/1.3.7.tether.min.js"></script>

<script src="<?php echo e(asset('js/laracrud.js')); ?>" ></script>
<script src="js/laracrud.js"></script>
<?php /**PATH C:\laragon32\www\app\resources\views/layouts/_scripts.blade.php ENDPATH**/ ?>