
<div class="modal fade" id="create">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">
					<span>x</span>
				</button>
			</div>
				<div class="modal-body">
					<h4 class="display-6">Nuevo Banco</h4>

                <form id="form-create-banco" name="form-create-banco" class="form-horizontal">
					
					

				
					
					
					<label  for="nombre" >Nombre Banco:</label> 
					<i class="glyphicon glyphicon-user">			
					<input class="form-control bg-light shadow-sm <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php else: ?> border-0 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " type="text" name="nombre" id="nombre" onkeyup="mayusculas(this);"
					value="" maxlength="60"></i>
			    
					<?php $__errorArgs = ['banco'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			
				
					
					<br>
					
					<div class="col-sm-offset-2 col-sm-10">
	                     <button class="btn btn-success btn-submit">Guardar</button>
	                     
	                     <a class="btn btn-secondary" href="#" class="close" data-dismiss="modal">Cancelar</a>

                 	</div>
					
					
				
				
				</form>					
			</div>
		</div>
	</div>
</div>	

</div>
<script type="text/javascript">

   

    $.ajaxSetup({

        headers: {

            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

        }

    });

   

    $(".btn-submit").click(function(e){

  

        e.preventDefault();

   

        var nombre = $("input[name=nombre]").val();

        // var password = $("input[name=password]").val();

        // var email = $("input[name=email]").val();

   

        $.ajax({

           type:'POST',

           url:"<?php echo e(route('ajaxRequest.post')); ?>",

           data:{name:nombre},

           success:function(data){

              alert(data.success);

           }

        });

  

	});

</script>

<?php /**PATH C:\laragon32\www\app\resources\views/bancos/create.blade.php ENDPATH**/ ?>