<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title>Laravel Ajax CRUD Example Tutorial with - CodingDriver</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
  <link rel="stylesheet" href="https://cdn.datatables.net/r/bs-3.3.5/jq-2.1.4,dt-1.10.8/datatables.min.css"/>

  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>
</head>
  <style>
  .alert-message {
    color: red;
  }
</style>
<body>

<div class="container">
    <h2 style="margin-top: 12px;" class="alert alert-success">Laravel Ajax CRUD Application -
       <a href="https://www.codingdriver.com" target="_blank" >CodingDriver</a>
     </h2><br>
     <div class="row" style="clear: both;margin-top: 18px;">
       <div class="col-12 text-right">
         <a href="javascript:void(0)" class="btn btn-success mb-3" id="create-new-banco" onclick="addBanco()">Nuevo Banco</a>
       </div>
    </div>
    <div class="row">
        <div class="col-12">
          <table id="laravel_crud" class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $bancos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr id="row_<?php echo e($banco->id); ?>">
                   <td><?php echo e($banco->id); ?></td>
                   <td><?php echo e($banco->nombre); ?></td>
                   <td><a href="javascript:void(0)" data-id="<?php echo e($banco->id); ?>" onclick="editBanco(event.target)" class="btn btn-info">Editar</a></td>
                   <td>
                    <a href="javascript:void(0)" data-id="<?php echo e($banco->id); ?>" class="btn btn-danger" onclick="deleteBanco(event.target)">Eliminar</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
       </div>
    </div>
</div>
<div class="modal fade" id="banco-modal" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
            <h4 class="modal-title"></h4>
        </div>
        <div class="modal-body">
            <form name="userForm" class="form-horizontal">
               <input type="hidden" name="banco_id" id="banco_id">
                <div class="form-group">
                    <label for="name" class="col-sm-2">Nombre</label>
                    <div class="col-sm-12">
                        <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Agregue Nombre de Banco">
                        <span id="bancoError" class="alert-message"></span>
                    </div>
                </div>

                
            </form>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-primary" onclick="createBanco()">Guardar</button>
        </div>
    </div>
  </div>
</div>
</body>

<script>
  $('#laravel_crud').DataTable();
  function addBanco() {
    $('#banco-modal').modal('show');
  }

  function editBanco(event) {
    var id  = $(event).data("id");
    let _url = `/bancos/${id}`;
    $('#bancoError').text('');
    // $('#descriptionError').text('');
    
    $.ajax({
      url: _url,
      type: "GET",
      success: function(response) {
          if(response) {
            $("#banco_id").val(response.id);
            $("#nombre").val(response.nombre);
            // $("#description").val(response.description);
            $('#banco-modal').modal('show');
          }
      }
    });
  }

  function createBanco() {
    var nombre = $('#nombre').val();
    // var description = $('#description').val();
    var id = $('#banco_id').val();

    let _url     = `/bancos`;
    let _token   = $('meta[name="csrf-token"]').attr('content');

      $.ajax({
        url: _url,
        type: "POST",
        data: {
          id: id,
          title: nombre,
          // description: description,
          _token: _token
        },
        success: function(response) {
            if(response.code == 200) {
              if(id != ""){
                $("#row_"+id+" td:nth-child(2)").html(response.data.nombre);
                // $("#row_"+id+" td:nth-child(3)").html(response.data.description);
              } else {
                $('table tbody').prepend('<tr id="row_'+response.data.id+'"><td>'+response.data.id+'</td><td>'+response.data.nombre+'</td><td><td><a href="javascript:void(0)" data-id="'+response.data.id+'" onclick="editBanco(event.target)" class="btn btn-info">Editar</a></td><td><a href="javascript:void(0)" data-id="'+response.data.id+'" class="btn btn-danger" onclick="deleteBanco(event.target)">Eliminar</a></td></tr>');
              }
              $('#nombre').val('');
              // $('#description').val('');

              $('#banco-modal').modal('hide');
            }
        },
        error: function(response) {
          $('#nombreError').text(response.responseJSON.errors.title);
          // $('#descriptionError').text(response.responseJSON.errors.description);
        }
      });
  }

  function deleteBanco(event) {
    var id  = $(event).data("id");
    let _url = `/bancos/${id}`;
    let _token   = $('meta[name="csrf-token"]').attr('content');

      $.ajax({
        url: _url,
        type: 'DELETE',
        data: {
          _token: _token
        },
        success: function(response) {
          $("#row_"+id).remove();
        }
      });
  }

</script>

</html><?php /**PATH C:\laragon32\www\app\resources\views/bancos/bancos.blade.php ENDPATH**/ ?>