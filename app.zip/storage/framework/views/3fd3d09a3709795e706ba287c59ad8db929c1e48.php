


<script>
	var nowDate = new Date();
	var today = new Date(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate(), 0, 0, 0, 0);
	    $('.datepicker').datepicker({
            format: "dd/mm/yyyy",
		    todayBtn: "linked",
		    language: "es",
		    // startDate: today,
		    daysOfWeekDisabled: "0",
		    autoclose: true

    });

    	$ ('. datetimepicker'). datetimepicker ({
        formato: 'HH: mm: ss'
    });
</script>
<?php /**PATH C:\laragon\www\app\resources\views/layouts/_scripts.blade.php ENDPATH**/ ?>