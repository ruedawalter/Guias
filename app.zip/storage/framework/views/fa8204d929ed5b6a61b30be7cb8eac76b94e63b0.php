<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Reporte de Guias Remitentes</title>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<style type="text/css">
  		@page  {
  			size: 29.7cm 21cm;
  			margin: 0cm;
  			font-size: 12px;
        font-family: Arial, Helvetica, Verdana;

  		}
  		body {
        font-size: 12px;
        font-family: Arial, Helvetica, Verdana;
        margin-top: 3cm;
        margin-left:0cm;
        margin-right: 0cm;
        margin-bottom: 3cm;

  		}
  		header {
  			position: fixed;
  			top: 1cm;
  			left:1cm;
  			right: 1cm;
  			height: 1cm;
  			/*background-color: #2f069d;*/
  			color: #fe5442;
  			text-align: left;
  			line-height: 25px;
        font="Comic Sans MS, Arial, MS Sans Serif";
  		}
  		footer {
  			position: fixed;
  			bottom: 0cm;
  			left:0cm;
  			right: 0cm;
  			height: 1cm;
  			background-color: #2f069d;
  			color: #fe5442;
  			text-align: center;
  			line-height: 25px;
  		}
  		.page-break {
    			page-break-after: always;
		}
    .total {
      color:blue;
      font-size: 18px;
      text-align: right;


    }
	</style>
</head>
<body>
	<header>
		<img alt="Gutierrez Courier" src="img/logo.png" width="50" height="50" ><p><strong>Control de Guias V-1.0</p></strong>
	</header>
<div class="container">
	<h3 style="text-align: center">Reporte de Guias - Remitentes</h3>
  <h3 style="text-align: left">Remitente:   <?php echo e($guias[0]->remitente); ?> </h3>


<table class="table table-striped text-center">
  <thead>
    <tr>
      <th scope="col">Fecha</th>
      <th scope="col">Guia</th>
      <th scope="col">Cliente</th>
      <th scope="col">Direccion</th>
      <th scope="col">Distrito</th>
      <th scope="col">Monto</th>
      <th scope="col">Monto Servicio</th>
      <th scope="col">Monto Recaudado</th>
      

    </tr>
  </thead>
  <tbody>
    <?php
        $totalm=0;
        $totals=0;
        $totalc=0;
    ?>
  	<?php $__currentLoopData = $guias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guias): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
          $totalm+=$guias->monto;//sumanos los valores, ahora solo fata mostrar dicho valor
          $totals+=$guias->smonto;
          $totalc=$totalm + $totals;
        ?>
   <tr>
      <th scope="row"><?php echo e($guias->fecha); ?></th>
      <td><?php echo e($guias->guia); ?></td>
      <td><?php echo e($guias->cliente); ?></td>
      <td><?php echo e($guias->direccionc); ?></td>
      <td><?php echo e($guias->distrito); ?></td>
      <td><?php echo e(number_format($guias->monto, 2)); ?></td>
      <td><?php echo e(number_format($guias->smonto, 2)); ?></td>
      <td><?php echo e(number_format($guias->totald, 2)); ?></td>
      

    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </tbody>

</table>




 </td>

  <div class="total">Total  a depositar --> <strong><?php echo e((number_format($totalm,2))); ?></strong> </div>
  <div class="total">Total  servicio    --> <strong><?php echo e((number_format($totals,2))); ?></strong>  </div>
  <div class="total">Total  cobrado     --> <strong><?php echo e((number_format($totalc,2))); ?></strong>  </div>

</div>



<script type="text/php">
        if ( isset($pdf) ) {
            $pdf->page_script('
                $font = $fontMetrics->get_font("Arial, Helvetica, sans-serif", "normal");
                $pdf->text(730, 570, "Pág $PAGE_NUM de $PAGE_COUNT", $font, 10);
                $pdf->text(62, 570, "https://gutierrezcourier.com" , $font, 10);
            ');
        }
    	</script>
</body>
</html><?php /**PATH C:\laragon\www\app\resources\views/pdf/remrg.blade.php ENDPATH**/ ?>