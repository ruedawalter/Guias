

<?php $__env->startSection('title', 'Agente | ' . $agente->nombres); ?>

<?php $__env->startSection('content'); ?>

<div class="container">

	<div class="bg-white p-5 redounded shadow">
		

	<h1><?php echo e($agente->nombres); ?></h1>
	<p class="lead text-secondary"></p>

	

	<p class="text-secondary"> Teléfono Celular: <?php echo e($agente->cel); ?>  </p>

	<p class="text-secondary"> Correo Electrónico: <?php echo e($agente->email); ?>  </p>
	
	<p class="text-black-50">Creado <?php echo e($agente->created_at->diffForHumans()); ?></p>
	
	<?php if(is_null($agente->updated_at)): ?>

		<p>Sin actualizaciones</p> 
	
	<?php else: ?>

		<p class="text-black-50">Actualizado <?php echo e($agente->updated_at->diffForHumans()); ?></p>
	

	<?php endif; ?>

	<dic class="d-flex justify-content-between align-items-center">	



		<a class="btn btn-primary" href="<?php echo e(route('agentes.index')); ?>">Regresar</a>
		
	<?php if(auth()->guard()->check()): ?>
	<div class="btn-group btn-group-sm">
		<a class="btn btn-primary" 
		href="<?php echo e(route('agentes.edit', $agente)); ?>"
		>Editar</a>

		<a class="btn btn-danger"
		href="#" onclick="document.getElementById('delete-agente').submit()"
		>Eliminar</a>
		
	</div>	
		<form class="d-none" id="delete-agente" method="POST" action="<?php echo e(route('agentes.destroy', $agente)); ?>">

			<?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
			
		</form>	

	
	<?php endif; ?>
	</div>
</div>	
</div>
</div>

	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon32\www\app\resources\views/agentes/show.blade.php ENDPATH**/ ?>