

<?php $__env->startSection('title', $fpago->nombre); ?>

<?php $__env->startSection('content'); ?>

<div class="container">

	<div class="bg-white p-5 redounded shadow">
		

	<h6>Banco <?php echo e($fpago->nombre); ?></h6>
	<p class="lead text-secondary"></p>

	<p class="text-secondary"> <?php echo e($fpago->nombre); ?>  </p>
	
	<p class="text-black-50">Creado <?php echo e($fpago->created_at->diffForHumans()); ?></p>
	
	<?php if(is_null($fpago->updated_at)): ?>

		<p>Sin actualizaciones</p> 
	
	<?php else: ?>

		<p class="text-black-50">Actualizado <?php echo e($fpago->updated_at->diffForHumans()); ?></p>
	

	<?php endif; ?>

	<dic class="d-flex justify-content-between align-items-center">	



		<a class="btn btn-primary" href="<?php echo e(route('fpagos.index')); ?>">Regresar</a>
		
	<?php if(auth()->guard()->check()): ?>
	<div class="btn-group btn-group-sm">
		<a class="btn btn-primary" 
		href="<?php echo e(route('fpagos.edit', $fpago)); ?>"
		>Editar</a>

		<a class="btn btn-danger"
		href="#" onclick="document.getElementById('delete-fpago').submit()"
		>Eliminar</a>
		
	</div>	
		<form class="d-none" id="delete-estado" method="POST" action="<?php echo e(route('fpagos.destroy', $fpago)); ?>">

			<?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
			
		</form>	

	
	<?php endif; ?>
	</div>
</div>	
</div>
</div>

	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon32\www\app\resources\views/fpagos/show.blade.php ENDPATH**/ ?>