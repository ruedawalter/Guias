

<?php $__env->startSection('title', 'Editar Remitentes'); ?>


<?php $__env->startSection('content'); ?>

<div class="card py-2 px2 mx-4 my-4">

	
	

	<form class="bg-white py-1 px-2 shadow redounded" method="POST" action="<?php echo e(route('remitentes.update', $remitente)); ?>" onsubmit="return stlf();">
		<h4>Editar Remitentes</h4>
		<hr>
		
		
		<?php echo method_field('PATCH'); ?>
		
		<?php echo $__env->make('remitentes._form', ['btntext' => 'Actualizar'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<a class="btn btn-secondary mx4 my-4" href="<?php echo e(route('remitentes.index')); ?>">Cancelar</a>

	</form>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon32\www\app\resources\views/remitentes/edit.blade.php ENDPATH**/ ?>