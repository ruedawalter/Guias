

<?php $__env->startSection('title', 'Agregar Cliente'); ?>


<?php $__env->startSection('content'); ?>

<div class="card py-2 px2 mx-4 my-4">

	
	

	<form class="bg-white py-1 px-2 shadow redounded" method="POST" action="<?php echo e(route('clientes.store')); ?>" onsubmit="return stlf();" >
		
							
		<?php echo $__env->make('clientes._form', ['btntext' => 'Guardar'] , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<a class="btn btn-secondary mx4 my-4" href="<?php echo e(route('clientes.index')); ?>">Cancelar</a>	
		 <br>

	</form>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\app\resources\views/clientes/create.blade.php ENDPATH**/ ?>