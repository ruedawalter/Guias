

<?php $__env->startSection('title', 'Distritos'); ?>


<?php $__env->startSection('content'); ?>

<div class="container">	
	<div class="card py-2 px-2">
	<div class="d-flex justify-content-between aling-items-center mb-3">
		
	<h3>Agentes</h3>
	
	<?php if(auth()->guard()->check()): ?>

		<a class="btn btn-primary  my-auto" 
			href = "<?php echo e(route('distritos.create')); ?>"
			>Nuevo
		</a>

	<?php endif; ?>
	</div>

	
	<p class="lead text-secondary">Listado de Distritos</p>

<ul class="list-group text-secondary">
	<table WIDTH="100%" >
		<tr >
			<th class="mr-3 shadow-sm border-1 mb-3 shadow-sm text-color:black">Nombres</th>
		

			<th class="mr-3 shadow-sm border-1 mb-3 shadow-sm text-center">Creado</th>
		</tr>
		

		
		<?php $__empty_1 = true; $__currentLoopData = $distritos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $distrito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 
			<tr >
			
			<td class="shadow-sm border-1 mb-3 shadow-sm text-Left" WIDTH="50%" >
				<a class="d-flex text-secondary justify-content-between aling-item-center" 
				href="<?php echo e(route('distritos.show',$distrito)); ?>">
				<spam class="font-weight-bold">
					<?php echo e($distrito->distrito); ?>

				</spam>
			</td>
			

			<td class="shadow-sm border-1 mb-3 shadow-sm text-center" WIDTH="25%">
					<?php if(is_null($distrito->created_at)): ?>

						<p>Sin actualizaciones</p> 
	
					<?php else: ?>

					<p class="text-black-50"> <?php echo e($distrito->created_at); ?></p>	

					<?php endif; ?>
			</td>
			</tr>	
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
	
			<li class="list-group-item border-0 mb-3 shadow-sm">
				No hay registros
			</li>

		<?php endif; ?>
		
	</table>
	
		<?php echo e($distritos->links()); ?>


</ul>

</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon32\www\app\resources\views/distritos/index.blade.php ENDPATH**/ ?>