

<?php $__env->startSection('title', $banco->nombre); ?>

<?php $__env->startSection('content'); ?>

<div class="container">

	<div class="bg-white p-5 redounded shadow">
		

	<h6>Banco <?php echo e($banco->nombre); ?></h6>
	<p class="lead text-secondary"></p>

	<p class="text-secondary"> <?php echo e($banco->nombre); ?>  </p>
	
	<p class="text-black-50">Creado <?php echo e($banco->created_at->diffForHumans()); ?></p>
	
	<?php if(is_null($banco->updated_at)): ?>

		<p>Sin actualizaciones</p> 
	
	<?php else: ?>

		<p class="text-black-50">Actualizado <?php echo e($banco->updated_at->diffForHumans()); ?></p>
	

	<?php endif; ?>

	<dic class="d-flex justify-content-between align-items-center">	



		<a class="btn btn-primary" href="<?php echo e(route('bancos.index')); ?>">Regresar</a>
		
	<?php if(auth()->guard()->check()): ?>
	<div class="btn-group btn-group-sm">
		<a class="btn btn-primary" 
		href="<?php echo e(route('bancos.edit', $banco)); ?>"
		>Editar</a>

		<a class="btn btn-danger"
		href="#" onclick="document.getElementById('delete-banco').submit()"
		>Eliminar</a>
		
	</div>	
		<form class="d-none" id="delete-banco" method="POST" action="<?php echo e(route('bancos.destroy', $banco)); ?>">

			<?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
			
		</form>	

	
	<?php endif; ?>
	</div>
</div>	
</div>
</div>

	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon32\www\app\resources\views/bancos/show.blade.php ENDPATH**/ ?>