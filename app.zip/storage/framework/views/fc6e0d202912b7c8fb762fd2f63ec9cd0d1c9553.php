<footer class="bg-white text-center text-black-50 ">

			<?php echo e(config('app.name')); ?>  | Copyrigths @ <?php echo e(date('Y')); ?> WR Soluciones <a class="img-fluid " href="https://wa.me/51917921461">
			<img class="img-fluid" src="<?php echo e(asset('img/whatsapp.png')); ?>" width="15" height="15"></a>
 			
</footer>	<?php /**PATH C:\laragon32\www\app\resources\views/layouts/_footer.blade.php ENDPATH**/ ?>