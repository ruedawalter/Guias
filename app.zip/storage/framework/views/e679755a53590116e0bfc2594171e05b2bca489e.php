<?php echo csrf_field(); ?> 	

		<div class="form-group">

			<label  for="nombre" >Servicios:</label>  
			
			<input class="form-control bg-light shadow-sm <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php else: ?> border-0 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " type="text" name="nombre" id="nombre" onkeyup="mayusculas(this);"
			value="<?php echo e(old('nombre', $servicio->nombre)); ?>" maxlength="60">
			<?php $__errorArgs = ['servicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>	
		
		

		<button class="btn btn-primary ml-4 mx4 my-4"><?php echo e($btntext); ?></button><?php /**PATH C:\laragon32\www\app\resources\views/servicios/_form.blade.php ENDPATH**/ ?>