<?php echo e($slot); ?>

<?php /**PATH C:\laragon32\www\app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>