

<?php $__env->startSection('title', 'Remitente'); ?>


<?php $__env->startSection('content'); ?>

<div class="container">	
	<div class="d-flex justify-content-between aling-items-center mb-3">
		
	<h4 class="display-4 mb-0">Remitente</h4>
	
	<?php if(auth()->guard()->check()): ?>

		<a class="btn btn-primary  my-auto" 
			href = "<?php echo e(route('remitentes.create')); ?>"
			>Nuevo
		</a>

	<?php endif; ?>
	</div>

	
	<p class="lead text-secondary"></p>

<ul class="list-group text-secondary">
		
		<?php $__empty_1 = true; $__currentLoopData = $remitentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $remitente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 
			<li class="list-group-item border-0 mb-3 shadow-sm">
				<a 
				class="d-flex text-secondary justify-content-between aling-item-center" 
				href="<?php echo e(route('remitentes.show',$remitente)); ?>">
				<spam class="font-weight-bold">
					<?php echo e($remitente->nombre); ?>

				</spam>

				<spam class="text-black-50">
					<?php echo e($remitente->created_at->format('d/m/y')); ?>

				</spam>	

				</a></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
	
			<li class="list-group-item border-0 mb-3 shadow-sm">
				No hay registros
			</li>

	<?php endif; ?>
	
		<?php echo e($remitentes->links()); ?>


</ul>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon32\www\app\resources\views/remitentes/index.blade.php ENDPATH**/ ?>