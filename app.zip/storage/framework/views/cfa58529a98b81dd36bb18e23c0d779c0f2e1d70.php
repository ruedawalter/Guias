<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <!-- Bootstrap 3.3.5 -->
    

   

   
    <!-- Scripts -->
   
    
    
    
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <script type="text/javascript" src="<?php echo e(asset('js/stlf.js')); ?>" ></script>

    


    <!-- Fonts -->
   
    
 
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">


    <?php /**PATH C:\laragon32\www\app\resources\views/layouts/_head.blade.php ENDPATH**/ ?>