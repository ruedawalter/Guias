

<?php $__env->startSection('title', 'Guias'); ?>

<?php $__env->startSection('content'); ?>
  <?php if(Auth::user()->id_rol == "3"): ?>
  <div class="container" style="width:100%">
    <div class="row justify-content-center">
    
      <div class="card-body">
        <div class="card-header">
          <div class="row">
            <div class="col clearfix">

              <span class="float-right"><a class="btn btn-success my-auto" href="javascript:void(0)" id="createNewguia" alt="Nuevo"> <i class="fas fa-plus"></i>  Nueva </a></span>
              <span class="float-left"><h1><i class="fas fa-truck"></i>   Guias</h1></span>
            </div>
          </div>
        </div>
        <hr>
        <p></p>
      <div class="alert Alert-success">
        <span><label type="hidden" name="alert" id="alert"></label></span>
      </div>
    <table class="table table-bordered data-table dt-responsive wrap" style="width:100%">
        <thead>
            <tr>
                <th width="5px">No</th>
                <th width="15%">Guia</th>
                <th width="60%">guia</th>
                
                <th width="15%">Distrito</th>
                <th width="10%">Acción</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>
</div>
</div>

<div class="modal fade" id="ajaxModel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
                  <button type="button" class="close" data-dismiss="modal">
                      <span>×cerrar</span>
                  </button>
            <div class="modal-header">
                <h4 class="modal-title" id="modelHeading"></h4>
            </div>
            <div class="modal-body">
                <form id="guiaForm" name="guiaForm" class="form-horizontal">
                   <input type="hidden" name="guia_id" id="guia_id">
                    <div class="form-group">
                          <div class="col clearfix ">
                            <span class="col-md-8"><label  for="nombre" >Nombres :</label>
                            <input class="form-control bg-light shadow-sm " type="text" name="nombre" id="nombre" onkeyup="mayusculas(this);" value="" maxlength="60" placeholder="Nombre del guia"></span>

                            
                          </div>

                        <div class="col clearfix">
                            <span class="col-md-8"><label  for="direccion" >Direción:</label>
                            <input class="form-control input-lg bg-light shadow-sm"style="" type="text" name="direccion" id="direccion" onkeyup="mayusculas(this);" value="" maxlength="100" placeholder="Dirección del guia"></span>
                        </div>


                        <div class="col clearfix">
                            <span class="float-left"><label  for="distrito_id" >Distrito :</label>
                            <select class="form-control bg-light shadow-sm col-12" name ="distrito_id" id="distrito_id"  class="form-control">
                              <option value="">--Seleccione Distrito--</option>
                                <?php $__currentLoopData = $distritos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $distrito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($distrito->id); ?>"><?php echo e($distrito->distrito); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select></span>
                          </div>
                          <p></p>
                          <div class="col clearfix">
                            <span class="float-left"><label  for="cel" >Teléfono Fijo:</label>
                            <input class="form-control bg-light shadow-sm "style="" type="text" name="telefono" id="telefono" value="" maxlength="10" placeholder="Telefono Fijo del guia" onkeypress='return numeros(event)'/></span>
                            <span class="float-right"><label  for="cel" >Teléfono Celular:</label>
                            <input class="form-control bg-light shadow-sm " type="text" name="cel" id="cel" value="" maxlength="9" placeholder="Telefono móvil 9## #### ###" onkeypress='return numeros(event)'/>
                            </span>
                          </div>

                        </div>
                    </div>
                    <div align="center">
                     <button type="submit" class="btn btn-primary" id="saveBtn" value="create">Guardar
                     </button>
                    </div>
                    <p></p>
                    <hr>
                </form>
            </div>
        </div>
    </div>
</div>
</div>
</div>


</body>
<script type="text/javascript">
  $(function () {
      $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
    });
    var table = $('.data-table').DataTable({
        processing: true,
        serverSide: true,
        language: {
             "url": "js/Spanish.json"
           },
        ajax: "<?php echo e(route('admguia')); ?>",
        columns: [
            {data: 'DT_RowIndex', name: 'DT_RowIndex'},
            {data: 'nombre', name: 'nombre'},
            {data: 'distritos_pk.distrito', name: 'distritos_pk.distrito'},
            // {data: 'distrito_id', name: 'distrito_id'},
            {data: 'cel', name: 'cel'},
            {data: 'action', name: 'action', orderable: false, searchable: false},
        ]
    });
    $('#createNewguia').click(function () {
        $('#saveBtn').val("create-guia");
        $('#guia_id').val('');
        $('#guiaForm').trigger("reset");
        $('#modelHeading').html("Nuevo guia");
        $('#ajaxModel').modal('show');
        $('#saveBtn').html('Guardar');
        // $('#telefono').val('S/Tlf');
    });
    $('body').on('click', '.editguia', function () {
      var guia_id = $(this).data('id');
      $.get("<?php echo e(route('admguia')); ?>" +'/' + guia_id +'/edit', function (data) {
          $('#modelHeading').html("Editar guia");
          $('#saveBtn').val("edit-user");
          $('#ajaxModel').modal('show');
          $('#guia_id').val(data.id);
          $('#nombre').val(data.nombre);
          // $('#email').val(data.email);
          $('#direccion').val(data.direccion);
          $('#distrito_id').val(data.distrito_id);
          // $('#distrito_id').html(data.distrito);
          $('#telefono').val(data.telefono);
          $('#cel').val(data.cel);
          $('#saveBtn').html('Guardar');
      })
   });

    $('#saveBtn').click(function (e) {
        e.preventDefault();
        $(this).html('Guardando....');
        valguia();
        $.ajax({
          data: $('#guiaForm').serialize(),
          url: "<?php echo e(route('guias.store')); ?>",
          type: "POST",
          dataType: 'json',
          success: function (data) {
              $("#alert").show();
                $("#alert").html('<h6 style="margin-top: 12px;" class="alert alert-success">guia guardado  correctamente</h6>');
                setTimeout(function() {
                $('#alert').fadeOut('slow');
                }, 2500);

              $('#guiaForm').trigger("reset");
              $('#ajaxModel').modal('hide');
              table.draw();
        },
          error: function (data) {
              $('#modelHeading').html("Error al guardar");
              console.log('Error:', data);
              $('#saveBtn').html('Guardar');
          }
      });
    });
    $('body').on('click', '.deleteguia', function () {
        var guia_id = $(this).data("id");
        var opcion = confirm("Esta usted seguro que quiere eliminar este guia?")
        if (opcion == true){
        $.ajax({
            type: "DELETE",
            url: "<?php echo e(route('guias.store')); ?>"+'/'+guia_id,
            success: function (data) {
                $("#alert").show();
                $("#alert").html('<h6 style="margin-top: 12px;" class="alert alert-success">guia eliminado correctamente</h6>');
                setTimeout(function() {
                $('#alert').fadeOut('slow');
                }, 2500);
                table.draw();
            },
            error: function (data) {
                console.log('Error:', data);
            }

        });
        }
    });
  });
</script>
<?php else: ?>

  <?php echo $__env->make('layouts._denegado', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\app\resources\views/guias/adm/index.blade.php ENDPATH**/ ?>