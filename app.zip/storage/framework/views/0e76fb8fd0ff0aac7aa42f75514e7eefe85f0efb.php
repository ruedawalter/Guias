

<?php $__env->startSection('title', 'Agregar Proveedor'); ?>


<?php $__env->startSection('content'); ?>

<div class="card py-2 px2 mx-4 my-4">

	
	

	<form class="bg-white py-1 px-2 shadow redounded" method="POST" action="<?php echo e(route('proveedores.store')); ?>">
		<h3 class="card-header">Nuevo Proveedor</h3>
		<br>
							
		<?php echo $__env->make('proveedores._form', ['btntext' => 'Guardar'] , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<a class="btn btn-secondary mx4 my-4" href="<?php echo e(route('proveedores.index')); ?>">Cancelar</a>	
		 <br>

	</form>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon32\www\app\resources\views/proveedores/create.blade.php ENDPATH**/ ?>