<?php
    exec("php artisan key:generate");